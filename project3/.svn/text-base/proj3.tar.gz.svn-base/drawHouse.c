#include "picture.h"
int drawHouse(int x, int y) {

   move(y, x);
   addstr ("^");
   move(y+1, x-2);
   addstr ("// \\\\");
   move(y+2, x-4);
   addstr ("//-----\\\\");
   move(y+3, x-2);
   addstr ("XXXXX");
   move(y+4, x-2);
   addstr ("XXX X");
   move(y+5, x-2);
   addstr ("XXX X");
   move(0, 0);
   refresh();

   return 0;
}
