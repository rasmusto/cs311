#include "picture.h"
int drawTree(int x, int y) {

   move(y, x);
   addstr ("^");
   move(y+1, x-1);
   addstr ("<^>");
   move(y+2, x-2);
   addstr ("<<T>>");
   move(y+3, x-3);
   addstr ("<<VTV>>");
   move(y+4, x-4);
   addstr ("<<<VTV>>>");
   move(y+5, x);
   addstr ("T");
   move(0, 0);
   refresh();

   return 0;
}
